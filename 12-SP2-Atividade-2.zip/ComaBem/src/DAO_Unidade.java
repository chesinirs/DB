import java.sql.*;
public class DAO_Unidade {
    Connection conexao;
    public void consulta(){
        try {
            conexao=new ConexaoDB().getConexao();
            Statement stm = conexao.createStatement();//comunicacao com o banco
            ResultSet rs = stm.executeQuery("Select * from unid");//comando enviado ao banco
            while (rs.next()) {
                System.out.println("Codigo:" + rs.getString(1));
                System.out.println("Nome:" + rs.getString(2));
            }
            this.conexao.close();
        }
        catch (Exception e){
            System.out.println("Unidade - Erro de consulta" + e);
        }
    }
    public void inserir(Unidade u1){
        try {
            conexao=new ConexaoDB().getConexao();
            String sql = "insert into unid values(default,?)";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setString(1,u1.getUnid_nome());
            pstm.execute();
            this.conexao.close();
        }
        catch (Exception e){
            System.out.println("Unidade - Erro de insercao" + e);
        }
    }
    public void alterar(Unidade u1){
        try {
            conexao=new ConexaoDB().getConexao();
            String sql = "update unid set unid_nome=? where unid_id=?";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setString(1,u1.getUnid_nome());
            pstm.setInt(2,u1.getUnid_id());
            pstm.execute();
            this.conexao.close();
        }
        catch (Exception e){
            System.out.println("Unidade - Erro de alteracao" + e);
        }
    }
    public void excluir(Unidade u1){
        try {
            conexao=new ConexaoDB().getConexao();
            String sql = "delete from unid where unid_id=?";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setInt(1,u1.getUnid_id());
            pstm.execute();
            this.conexao.close();
        }
        catch (Exception e){
            System.out.println("Unidade - Erro de exclusao" + e);
        }
    }
}