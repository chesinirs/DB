import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Produto p1 = new Produto();
        Unidade u1 = new Unidade();
        String opcaoString;//variavel para leitura de opcoes dentro do main
        DAO_Produto produtodao = new DAO_Produto(); //efetuara a chamada dos métodos dentro das classes
        DAO_Unidade unidadedao = new DAO_Unidade();//efetuara a chamada dos métodos dentro das classes
        Scanner teclado=new Scanner(System.in);//variavel que efetuara a leitura do teclado

        System.out.println("Deseja Encerrar (E) ou Continuar (C)?");
        opcaoString = teclado.next();//recebe o que sera lido do teclado

        while(opcaoString.equals("C") || opcaoString.equals("c")){
            System.out.println("Digite:\n U - Unidades de Medida\n P - Produto");
            opcaoString = teclado.next();
            if (opcaoString.equals("U") || opcaoString.equals("u")){
                System.out.println("Digite:\n C - Consultar\n I - Inserir\n A - Alterar\n E - Excluir");
                opcaoString = teclado.next();
                switch (opcaoString){
                    case "C":
                        unidadedao.consulta();
                        break;
                    case "I":{
                        System.out.println("Insira o nome da nova unidade:");
                        u1.setUnid_nome(teclado.next());
                        unidadedao.inserir(u1);
                        break;
                    }
                    case "A":{
                        System.out.println("Insira o novo nome da Unidade:");
                        u1.setUnid_nome(teclado.next());
                        System.out.println("Insira o Id da Unidade a ser alterada:");
                        u1.setUnid_id(Integer.parseInt(teclado.next()));
                        unidadedao.alterar(u1);
                        break;
                    }
                    case "E":{
                        System.out.println("Insira o ID da unidade a ser excluida:");
                        u1.setUnid_id(Integer.parseInt(teclado.next()));
                        unidadedao.excluir(u1);
                        break;
                    }
                }
            } else if (opcaoString.equals("P") || opcaoString.equals("p")) {
                System.out.println("Digite:\n C - Consultar\n I - Inserir\n A - Alterar\n E - Excluir");
                opcaoString = teclado.next();
                switch (opcaoString){
                    case "C":
                        produtodao.consulta();
                        break;
                    case "I":{
                        System.out.println("Insira o nome do novo produto:");
                        p1.setProd_nome(teclado.next());
                        System.out.println("Insira o valor:");
                        p1.setProd_valor(Double.parseDouble(teclado.next()));
                        System.out.println("Insira a quantidade:");
                        p1.setProd_qtde(Double.parseDouble(teclado.next()));
                        System.out.println("Insira o ID da Unidade:");
                        p1.setUnid_id(Integer.parseInt(teclado.next()));
                        produtodao.inserir(p1);
                        break;
                    }
                    case "A":{
                        System.out.println("Insira o novo nome do produto:");
                        p1.setProd_nome(teclado.next());
                        System.out.println("Insira o valor:");
                        p1.setProd_valor(Double.parseDouble(teclado.next()));
                        System.out.println("Insira a quantidade:");
                        p1.setProd_qtde(Double.parseDouble(teclado.next()));
                        System.out.println("Insira o ID da Unidade:");
                        p1.setUnid_id(Integer.parseInt(teclado.next()));
                        System.out.println("Insira o ID do Produto:");
                        p1.setProd_id(Integer.parseInt(teclado.next()));
                        produtodao.alterar(p1);
                        break;
                    }
                    case "E":{
                        System.out.println("Insira o ID do produto a ser excluido:");
                        p1.setProd_id(Integer.parseInt(teclado.next()));
                        produtodao.excluir(p1);
                        break;
                    }
                }
            } else{
                System.out.println("Opcao Invalida");
            }
            System.out.println("Deseja Encerrar (E) ou Continuar (C)?");
            opcaoString = teclado.next();
        }
    }
}