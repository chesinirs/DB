//classe ConexaoDB
import java.sql.*;

public class ConexaoDB { /*Classe para comunicacao com o banco de dados*/
    Connection conexao;
//Construtor ConexaoDB
    public ConexaoDB() { /*faz a conexao com o banco de dados*/
        try {//toda chamada ao DB precisa de um try catch
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Necessario passar o nome do host, usuario e senha
            conexao = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/produto",
                            "root",
                            "root");
            /*jdbc conector: mysql tipo do banco de dados://localhost url ou IP do banco:3306 porta de acesso ao banco/produto nome do banco*/
        } catch (Exception e) {
            System.out.println("Erro de conexao" + e);
        }
    }
    public Connection getConexao(){
        return this.conexao;
    }
}