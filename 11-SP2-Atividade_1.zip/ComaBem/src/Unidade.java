public class Unidade {
    private int unid_id;
    private String unid_nome;

    public int getUnid_id()
    {
        return this.unid_id;
    }

    public void setUnid_id(int id)
    {
        this.unid_id = id;
    }

    public String getUnid_nome()
    {
        return this.unid_nome;
    }

    public void setUnid_nome(String nome)
    {
        this.unid_nome = nome;
    }
}