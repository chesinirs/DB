public class Produto {
    int prod_id;
    String prod_nome;
    Double prod_valor;
    Double prod_qtde;
    int unid_id;

    public int getProd_id()
    {
        return prod_id;
    }

    public void setProd_id(int id)
    {
        this.prod_id = id;
    }

    public String getProd_nome()
    {
        return prod_nome;
    }

    public void setProd_nome(String nome)
    {
        this.prod_nome = nome;
    }

    public Double getProd_valor()
    {
        return prod_valor;
    }

    public void setProd_valor(Double valor)
    {
        this.prod_valor = prod_valor;
    }

    public Double getProd_qtde()
    {
        return prod_qtde;
    }

    public void setProd_qtde(Double qtde)
    {
        this.prod_qtde = qtde;
    }

    public int getUnid_id()
    {
        return unid_id;
    }

    public void setUnid_id(int id) {
        this.unid_id = id;
    }
}