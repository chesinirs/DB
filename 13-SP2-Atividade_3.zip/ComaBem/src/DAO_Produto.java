/**
 * biblioteca para comunicar com MYSQL
 */
import java.sql.*;

/**
 * construtor DAO_Produto com os metodos para execucao de QUERYS no DB
 */
public class DAO_Produto {
/**
* Objeto Connection
*/
    Connection conexao;
/**
* Metodo consulta de produto
*/
    public void consulta() {//fazer uma consulta no banco de dados
        try {
            conexao=new ConexaoDB().getConexao();
            Statement stm = conexao.createStatement();//comunicacao com o banco
            ResultSet rs = stm.executeQuery("Select * from prod");//comando enviado ao banco
            while(rs.next()){
                System.out.println("Codigo:"+rs.getString(1));
                System.out.println("Nome:"+rs.getString(2));
                System.out.println("Valor:"+rs.getString(3));
                System.out.println("Quantidade:"+rs.getString(4));
                System.out.println("Id da Unidade de medida:" +rs.getString(5));
            }
            this.conexao.close();
        }
        catch (Exception e) {
            System.out.println("Erro de consulta" + e);
        }
    }
/**
* Metodo inserir de produto
*/
    public boolean inserir(Produto p1) {//fazer uma insercao no banco de dados
        try {
            conexao=new ConexaoDB().getConexao();
            String sql = "insert into prod values(default,?,?,?,?)";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setString(1,p1.getProd_nome());
            pstm.setDouble(2,p1.getProd_valor());
            pstm.setDouble(3,p1.getProd_qtde());
            pstm.setInt(4,p1.getUnid_id());
            pstm.execute();
            this.conexao.close();
            return true;
        }
        catch (Exception e) {
            System.out.println("Erro de insercao" + e);
            return false;
        }
    }
/**
* Metodo alterar de produto
*/
    public void alterar(Produto p1) {//fazer uma alteracao no banco de dados
        try {//sempre colocar WHERE pra nao alterar toda tabela
            conexao=new ConexaoDB().getConexao();
            String sql = "update prod set prod_nome=?,prod_valor=?,prod_qtde=?,unid_id=? where prod_id=?";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setString(1,p1.getProd_nome());
            pstm.setDouble(2,p1.getProd_valor());
            pstm.setDouble(3,p1.getProd_qtde());
            pstm.setInt(4,p1.getUnid_id());
            pstm.setInt(5,p1.getProd_id());
            pstm.execute();
            this.conexao.close();
        }
        catch (Exception e) {
            System.out.println("Erro de alteracao" + e);
        }
    }

/**
* Metodo excluir de produto
*/
    public void excluir(Produto p1) {//fazer uma exclusao no banco de dados
        try {//sempre colocar WHERE pra nao alterar toda tabela
            conexao=new ConexaoDB().getConexao();
            String sql = "delete from prod where prod_id=?";//string com o comando que sera enviado ao banco
            PreparedStatement pstm = conexao.prepareStatement(sql);
            pstm.setInt(1,p1.getProd_id());
            pstm.execute();
            this.conexao.close();
        }
        catch (Exception e) {
            System.out.println("Erro de exclusao" + e);
        }
    }
}